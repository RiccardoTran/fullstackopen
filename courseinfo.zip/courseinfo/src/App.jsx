const Header = () => {
  const course = 'Half Stack application development';

  return (
    <div> 
      <h1>{course}</h1>
    </div>
  )
}

const Content = () => {
  const part1 = 'Fundamentals of React';
  const exercises1 = 10
  const part2 = 'Using props to pass data';
  const exercises2 = 7
  const part3 = 'State of a component';
  const exercises3 = 14

  return (
    <div>
      <p>
        {part1} {exercises1}
      </p>
      <p>
        {part2} {exercises2}
      </p>
      <p>
        {part3} {exercises3}
      </p>
      <Total exercises1={exercises1} exercises2={exercises2} exercises3={exercises3} />

    </div>
  )
}

const Total = (props) => {
  const {exercises1, exercises2, exercises3} = props
  const TotalExercises = exercises1 + exercises2 + exercises3

  return (
    <p>Number of exercises {exercises1} {'+'}  {exercises2} {'+'} {exercises3} {'= '} 
    {TotalExercises}</p>
  )
}

const App = () => {
  
  return (
    <div>
      <Header />
      <Content />
      
    </div>
  )
}

export default App