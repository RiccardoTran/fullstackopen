import { useState } from 'react'

const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>
    {text}
  </button>
)
const Statisticline = (props) => {
  return (
    <p>
      {props.text} {props.value}
    </p>
  )
}

const Statistics = (props) => {
  if (props.good+props.neutral+props.bad === 0){
  return (
    <div>{"No feedback given"}</div>
  )} else {return(
    <div>
    <div>{"good "}{props.good}</div>
    <div>{"neutral "}{props.neutral}</div>
    <div>{"bad "}{props.bad}</div>  
    <div>{"All "}{props.good+props.neutral+props.bad}</div>
    <div>{"average "}{props.good+props.bad*(-1)}</div>
    <div>{"positive% "}{props.good/(props.good+props.bad+props.neutral)}</div></div>
    )

  }

}

const App = () => {
  // save clicks of each button to its own state
  const [good, setGood] = useState(0)
  const [neutral, setNeutral] = useState(0)
  const [bad, setBad] = useState(0)
  
  
  const increaseGood = () => 
    setGood(good + 1)
  
  const increaseNeutral = () => 
    setNeutral(neutral + 1)
  
  const increaseBad = () => 
    setBad(bad + 1)
  
  return (
    <div><h1>give feedback</h1>
      <Button handleClick={increaseGood} text="good" />
      <Button handleClick={increaseNeutral} text="neutral" />
      <Button handleClick={increaseBad} text="bad" />
      <h1>Statistics</h1>
      <Statisticline text = {"good "} value = {good} />
      <Statisticline text = {"neutral "} value = {neutral} />
      <Statisticline text = {"bad "} value = {bad} />
      <Statisticline text = {"All "} value = {good+bad+neutral} />
      <Statisticline text = {"average "} value = {good-bad} />
      <Statisticline text = {"positive "} value = {good/(good+bad+neutral)} />




    </div>
  )
}

export default App

